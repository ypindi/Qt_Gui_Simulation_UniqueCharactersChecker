#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "utils.h"
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow) {
    ui->setupUi(this);
    connect(ui->checkButton, &QPushButton::clicked, this, &MainWindow::onCheckClicked);
}

MainWindow::~MainWindow() {
    delete ui;
}

void MainWindow::onCheckClicked() {
    QString input = ui->inputEdit->text();
    bool caseSensitive = ui->caseCheck->isChecked();

    if (input.isEmpty()) {
        QMessageBox::warning(this, "Input Error", "Please enter a string.");
        return;
    }

    auto [isUnique, uniqueChars] = hasUniqueCharacters(input.toStdString(), caseSensitive);

    if (!isUnique) {
        ui->resultLabel->setText("❌ Not Unique or Invalid Input");
    } else {
        QString charList;
        for (char ch : uniqueChars) {
            charList += ch;
            charList += ' ';
        }
        ui->resultLabel->setText("✅ Unique!\nCharacters: " + charList);
    }
}
