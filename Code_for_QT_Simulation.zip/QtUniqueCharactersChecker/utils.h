#pragma once
#include <string>
#include <unordered_set>
#include <vector>
#include <cctype>
#include <utility>

std::pair<bool, std::vector<char>> hasUniqueCharacters(const std::string& str, bool caseSensitive) {
    std::unordered_set<char> seen;
    std::vector<char> unique;

    for (char ch : str) {
        if (!std::isalnum(static_cast<unsigned char>(ch))) {
            return {false, {}};
        }

        char processedChar = caseSensitive ? ch : std::tolower(static_cast<unsigned char>(ch));

        if (seen.count(processedChar)) {
            return {false, unique};
        }

        seen.insert(processedChar);
        unique.push_back(ch);
    }

    return {true, unique};
}
